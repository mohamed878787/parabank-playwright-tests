@jakarta.xml.bind.annotation.XmlSchema(
        elementFormDefault=jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.parasoft.parabank.service;